import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CustomerView } from "@/components/coop/CustomerView";
import { WorkerView } from "@/components/coop/WorkerView";
import { AdminView } from "@/components/coop/AdminView";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "COOP-GIG AI — Cooperative Home Services, Bengaluru" },
      { name: "description", content: "Worker-owned home services platform with fair, transparent AI matching for plumbers, electricians, cleaners and more." },
      { property: "og:title", content: "COOP-GIG AI — Cooperative Home Services" },
      { property: "og:description", content: "Your home, taken care of by worker-owners. Fair matching, transparent governance." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type Role = "customer" | "worker" | "admin";
const roles: { id: Role; label: string }[] = [
  { id: "customer", label: "Customer" },
  { id: "worker", label: "Worker" },
  { id: "admin", label: "Admin / Governance" },
];

function Index() {
  const [role, setRole] = useState<Role>("customer");
  return (
    <div>
      <header className="fixed left-1/2 top-3 z-50 flex w-[calc(100%-1.5rem)] max-w-3xl -translate-x-1/2 items-center justify-between gap-2 rounded-full border border-border bg-card/90 px-3 py-2 shadow-lg backdrop-blur">
        <span className="shrink-0 whitespace-nowrap pl-2 text-sm font-extrabold tracking-tight text-foreground">COOP-GIG <span className="text-violet">AI</span></span>
        <div className="flex rounded-full bg-muted p-1">
          {roles.map((r) => (
            <button key={r.id} onClick={() => setRole(r.id)} className="relative rounded-full px-3 py-1.5 text-[11px] font-bold sm:text-xs">
              {role === r.id && <motion.span layoutId="pill" className="absolute inset-0 rounded-full bg-foreground" transition={{ type: "spring", stiffness: 400, damping: 30 }} />}
              <span className={`relative ${role === r.id ? "text-background" : "text-muted-foreground"}`}>{r.label}<span className="hidden sm:inline"> View</span></span>
            </button>
          ))}
        </div>
      </header>
      <AnimatePresence mode="wait">
        <motion.div key={role} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
          {role === "customer" && <CustomerView />}
          {role === "worker" && <WorkerView />}
          {role === "admin" && <AdminView />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
