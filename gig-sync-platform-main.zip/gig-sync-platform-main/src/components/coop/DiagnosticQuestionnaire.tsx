import { Bot } from "lucide-react";
import { getTree, outcomeMeta, type DiagOption, type DiagNode } from "./diagnostics";

export function DiagnosticQuestionnaire({
  service, answers, setAnswers, onCancel, onBook,
}: {
  service: string;
  answers: string[];
  setAnswers: (a: string[]) => void;
  onCancel: () => void;
  onBook: (priority: boolean) => void;
}) {
  const tree = getTree(service);
  // Walk the tree following the chosen answers.
  const path: { id: string; picked?: DiagOption }[] = [];
  let nodeId: string | undefined = tree.start;
  let result: DiagOption | undefined;
  for (let i = 0; nodeId && tree.nodes[nodeId]; i++) {
    const cur: DiagNode = tree.nodes[nodeId]!;
    const picked: DiagOption | undefined = cur.options.find((o) => o.label === answers[i]);
    path.push({ id: nodeId, picked });
    if (!picked) break;
    if (picked.outcome) { result = picked; break; }
    nodeId = picked.next;
  }

  const meta = result?.outcome ? outcomeMeta[result.outcome] : null;
  const toneCls = result?.outcome === "no_visit" ? "border-success/40 bg-success/10"
    : result?.outcome === "priority" ? "border-danger/40 bg-danger/10" : "border-gold/40 bg-gold-soft";

  return (
    <div className="space-y-4">
      <p className="flex items-start gap-2 rounded-2xl bg-gold-soft p-3 text-xs"><Bot className="h-4 w-4 shrink-0" /> A few quick checks help us avoid unnecessary visits — saving you money and our worker-owners time.</p>
      {path.map(({ id }, i) => {
        const node = tree.nodes[id]!;
        return (
          <div key={`${i}-${id}`}>
            <p className="mb-2 text-sm font-semibold">{node.q}</p>
            <div className="flex flex-wrap gap-2">
              {node.options.map((o) => (
                <button key={o.label} onClick={() => setAnswers([...answers.slice(0, i), o.label])} className={`rounded-full border px-4 py-1.5 text-xs font-semibold ${answers[i] === o.label ? "border-gold bg-gold text-gold-ink" : "border-cream-line"}`}>{o.label}</button>
              ))}
            </div>
          </div>
        );
      })}
      {result && meta && (
        <div className="space-y-3">
          <div className={`rounded-2xl border p-3 text-sm ${toneCls}`}>
            <p className="text-[10px] font-bold tracking-[0.2em]">{meta.label.toUpperCase()}</p>
            {result.advice && <p className="mt-1">{result.advice}</p>}
          </div>
          {result.outcome === "no_visit" ? (
            <>
              <button onClick={onCancel} className="w-full rounded-full border border-cream-line py-3 text-sm font-bold">It worked, cancel</button>
              <button onClick={() => onBook(false)} className="w-full rounded-full bg-gold py-3 text-sm font-bold text-gold-ink">Still not working — book</button>
            </>
          ) : (
            <button onClick={() => onBook(result.outcome === "priority")} className="w-full rounded-full bg-gold py-3 font-bold text-gold-ink">
              {result.outcome === "priority" ? "Confirm priority booking" : "Confirm booking"}
            </button>
          )}
        </div>
      )}
    </div>
  );
}
