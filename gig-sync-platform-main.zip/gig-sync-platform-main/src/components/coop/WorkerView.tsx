import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { MapPin, Clock, Scale, TrendingUp, Activity, HeartPulse, Briefcase, BarChart3, Dna, Check, Car } from "lucide-react";
import { Modal } from "./Modal";
import { Wallet, Brain, Lightbulb, BadgeCheck } from "lucide-react";

type Tab = "jobs" | "ledger" | "skills" | "earnings";

const jobs = [
  { id: 1, customer: "Priya Sharma", service: "Deep Home Cleaning", loc: "Koramangala 5th Block", price: 1249, time: "Today, 2:00 PM" },
  { id: 2, customer: "Rohan Iyer", service: "Kitchen Sanitization", loc: "Indiranagar", price: 899, time: "Today, 5:15 PM" },
  { id: 3, customer: "Ananya Bhat", service: "Appliance Cleaning", loc: "HSR Layout Sector 2", price: 649, time: "Tomorrow, 10:00 AM" },
];

const reasons = ["Score calculation seems incorrect", "Distance/ETA was misjudged", "My availability was not reflected", "Skill rating is outdated", "Other"];

export function WorkerView() {
  const [tab, setTab] = useState<Tab>("jobs");
  const [accepted, setAccepted] = useState<number[]>([]);
  const [appeal, setAppeal] = useState(false);
  const [reason, setReason] = useState(reasons[0]);
  const [note, setNote] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const tabs: { id: Tab; label: string; icon: typeof Briefcase }[] = [
    { id: "jobs", label: "Incoming Jobs", icon: Briefcase },
    { id: "ledger", label: "Opportunity Ledger", icon: BarChart3 },
    { id: "skills", label: "Skill & Welfare", icon: Dna },
    { id: "earnings", label: "Earnings", icon: Wallet },
  ];

  return (
    <div className="min-h-screen bg-slate-bg pb-28 text-foreground">
      <header className="bg-violet px-5 pb-6 pt-24 text-violet-ink">
        <div className="mx-auto flex max-w-md items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-full bg-violet-ink/20 font-bold">AR</div>
            <div>
              <p className="text-lg font-bold">Arjun Rao</p>
              <p className="text-xs opacity-80">Service Professional • Member-owner</p>
            </div>
          </div>
          <div className="rounded-2xl bg-violet-ink/15 px-3 py-2 text-right">
            <p className="text-[10px] font-semibold opacity-80">Equity Debt</p>
            <p className="font-bold">68/100</p>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-md px-5 pt-5">
        <AnimatePresence mode="wait">
          <motion.div key={tab} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.22 }} className="space-y-4">
            {tab === "jobs" && (
              <>
                {jobs.map((j) => {
                  const ok = accepted.includes(j.id);
                  return (
                    <div key={j.id} className="rounded-2xl border border-border bg-card p-4 shadow-sm">
                      <div className="flex justify-between">
                        <div>
                          <span className="rounded-full bg-violet-soft px-2 py-0.5 text-[10px] font-bold text-violet">NEW REQUEST</span>
                          <p className="mt-2 font-bold">{j.service}</p>
                          <p className="text-sm text-muted-foreground">{j.customer}</p>
                        </div>
                        <p className="text-lg font-bold">₹{j.price}</p>
                      </div>
                      <div className="mt-3 flex flex-wrap gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{j.loc}</span>
                        <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{j.time}</span>
                      </div>
                      <button
                        onClick={() => setAccepted(ok ? accepted.filter((x) => x !== j.id) : [...accepted, j.id])}
                        className={`mt-4 flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-bold transition ${ok ? "bg-success/15 text-success" : "bg-violet text-violet-ink hover:brightness-110"}`}
                      >
                        {ok ? <><Check className="h-4 w-4" /> Accepted — tap to undo</> : "Accept Request"}
                      </button>
                    </div>
                  );
                })}
                <div className="rounded-2xl border-2 border-dashed border-violet/40 bg-card p-4">
                  <p className="flex items-center gap-2 font-bold"><Scale className="h-4 w-4 text-violet" /> Why Was I Not Selected?</p>
                  <p className="mt-1 text-sm text-muted-foreground">AC Repair • Today 6:30 PM • BTM Layout</p>
                  <div className="mt-3 grid grid-cols-2 gap-2 text-center">
                    <div className="rounded-xl bg-violet-soft p-3"><p className="text-xs text-muted-foreground">Your score</p><p className="text-xl font-bold text-violet">82.4</p></div>
                    <div className="rounded-xl bg-muted p-3"><p className="text-xs text-muted-foreground">Selected worker</p><p className="text-xl font-bold">88.7</p></div>
                  </div>
                  <p className="mt-3 text-xs text-muted-foreground">Main gap: Distance / ETA (−4.1) and Skill Match on inverter ACs (−2.2).</p>
                  <button onClick={() => { setAppeal(true); setSubmitted(false); }} className="mt-3 w-full rounded-xl border border-violet py-2.5 text-sm font-bold text-violet hover:bg-violet-soft">
                    Challenge Decision (Algorithmic Appeal)
                  </button>
                </div>
              </>
            )}

            {tab === "ledger" && (
              <>
                <div className="grid grid-cols-3 gap-3">
                  {[["Eligible Jobs", "184"], ["Jobs Received", "71"], ["Capture Rate", "38.6%"]].map(([k, v]) => (
                    <div key={k} className="rounded-2xl border border-border bg-card p-3">
                      <p className="text-[10px] font-semibold text-muted-foreground">{k}</p>
                      <p className="mt-1 text-xl font-bold text-violet">{v}</p>
                    </div>
                  ))}
                </div>
                <div className="rounded-2xl border border-border bg-card p-4">
                  <p className="mb-3 text-sm font-bold">Last 6 weeks — jobs received</p>
                  <div className="flex h-28 items-end gap-2">
                    {[9, 14, 11, 8, 15, 14].map((v, i) => (
                      <motion.div key={i} initial={{ height: 0 }} animate={{ height: `${v * 6}%` }} transition={{ delay: i * 0.05 }} className="flex-1 rounded-t-lg bg-violet/80" />
                    ))}
                  </div>
                </div>
                <div className="rounded-2xl border border-border bg-card p-4 text-sm">
                  <p className="mb-2 font-bold">Jobs lost — why</p>
                  {[["Distance", 52], ["Availability", 38], ["Skill threshold", 23]].map(([k, v]) => (
                    <div key={k as string} className="flex justify-between py-1"><span className="text-muted-foreground">{k}</span><span className="font-semibold">{v}</span></div>
                  ))}
                </div>
                <div className="rounded-2xl bg-violet-soft p-4">
                  <p className="flex items-center gap-2 font-bold text-violet"><TrendingUp className="h-4 w-4" /> Opportunity Debt: 68/100</p>
                  <p className="mt-2 text-sm">Your recent exposure is below the cooperative median. The <b>Opportunity Equity</b> weight (10%) gives you an allocation boost of up to <b>+3.4 points</b> on matching jobs until your debt falls below 40.</p>
                </div>
              </>
            )}

            {tab === "earnings" && (
              <>
                <div className="rounded-2xl bg-violet p-5 text-violet-ink">
                  <p className="text-xs opacity-80">October earnings</p>
                  <p className="text-3xl font-bold">₹8,450</p>
                  <div className="mt-3 flex gap-6 text-sm"><span><b>11</b> jobs</span><span><b>₹768</b> avg payout</span></div>
                </div>
                <div className="rounded-2xl border border-border bg-card p-4">
                  <p className="mb-3 flex items-center gap-2 font-bold"><BadgeCheck className="h-4 w-4 text-violet" /> Trust Passport</p>
                  {[["Identity", "Verified (Aadhaar ••••)"], ["Skills", "4 verified"], ["Certifications", "AC Level 2, Electrical L1"], ["Reliability", "94 / 100"]].map(([k, v]) => (
                    <div key={k} className="flex justify-between border-b border-border py-2 text-sm last:border-0"><span className="text-muted-foreground">{k}</span><span className="font-semibold">{v}</span></div>
                  ))}
                </div>
              </>
            )}

            {tab === "skills" && (
              <>
                <div className="rounded-2xl border border-border bg-card p-4">
                  <p className="mb-4 font-bold">Skill Genome</p>
                  {[["Residential Wiring", 96], ["AC Diagnostics", 91], ["Residential Cleaning", 84], ["EV Charger Installation", 61]].map(([k, v]) => (
                    <div key={k as string} className="mb-4">
                      <div className="flex justify-between text-sm"><span>{k}</span><span className="font-bold text-violet">{v}%</span></div>
                      <div className="mt-1.5 h-2.5 rounded-full bg-muted">
                        <motion.div initial={{ width: 0 }} animate={{ width: `${v}%` }} transition={{ duration: 0.8 }} className="h-2.5 rounded-full bg-violet" />
                      </div>
                    </div>
                  ))}
                  <p className="flex gap-2 rounded-xl bg-violet-soft p-3 text-xs"><Lightbulb className="h-4 w-4 shrink-0 text-violet" /> Demand for EV chargers is up 28% in Bengaluru → complete Level 1 cert for +18% job eligibility.</p>
                </div>
                <div className="rounded-2xl border border-border bg-card p-4">
                  <p className="flex items-center gap-2 font-bold"><Brain className="h-4 w-4 text-violet" /> Cooperative Brain</p>
                  <p className="mt-1 text-sm text-muted-foreground">31/37 technicians resolved AC cooling issues by checking capacitor degradation first.</p>
                </div>
                <div className="rounded-2xl border border-warn/40 bg-card p-4">
                  <p className="flex items-center gap-2 font-bold"><HeartPulse className="h-4 w-4 text-warn" /> Wellbeing check</p>
                  <p className="mt-1 text-sm text-muted-foreground">Today: 7 jobs, 8.4 active hrs, 2.1 hr travel. Weekly utilization 82% — near your limit. We'll prefer nearby jobs for the rest of the day.</p>
                  <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                    <div className="flex items-center gap-2 rounded-xl bg-muted p-3"><Car className="h-4 w-4" /> 2.1 h travel</div>
                    <div className="flex items-center gap-2 rounded-xl bg-muted p-3"><Activity className="h-4 w-4" /> 8.4 h active</div>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      <nav className="fixed bottom-4 left-1/2 z-40 flex w-[calc(100%-2rem)] max-w-sm -translate-x-1/2 justify-around rounded-full border border-border bg-card p-2 shadow-xl">
        {tabs.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`flex flex-col items-center rounded-full px-2 py-1.5 text-[9px] font-semibold transition ${tab === t.id ? "bg-violet text-violet-ink" : "text-muted-foreground"}`}>
            <t.icon className="h-5 w-5" />{t.label}
          </button>
        ))}
      </nav>

      <Modal open={appeal} onClose={() => setAppeal(false)} title="Algorithmic Appeal" tone="violet">
        {submitted ? (
          <div className="text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-violet-soft"><Check className="h-7 w-7 text-violet" /></div>
            <p className="mt-3 font-bold">Appeal #AP-2041 submitted</p>
            <p className="text-sm text-muted-foreground">The cooperative board will review within 48 hours.</p>
            <button onClick={() => setAppeal(false)} className="mt-5 w-full rounded-xl bg-violet py-3 font-bold text-violet-ink">Done</button>
          </div>
        ) : (
          <form onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }} className="space-y-3">
            <p className="text-sm text-muted-foreground">AC Repair • 6:30 PM • 82.4 vs 88.7</p>
            {reasons.map((r) => (
              <label key={r} className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3 text-sm ${reason === r ? "border-violet bg-violet-soft" : "border-border"}`}>
                <input type="radio" name="reason" checked={reason === r} onChange={() => setReason(r)} className="accent-violet" /> {r}
              </label>
            ))}
            <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={3} placeholder="Add details for the cooperative board…" className="w-full rounded-xl border border-border p-3 text-sm outline-none focus:border-violet" />
            <button type="submit" className="w-full rounded-xl bg-violet py-3 font-bold text-violet-ink">Submit to Board Review</button>
          </form>
        )}
      </Modal>
    </div>
  );
}
