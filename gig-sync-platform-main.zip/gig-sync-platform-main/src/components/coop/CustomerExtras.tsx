import { useState } from "react";
import { BadgeCheck, CalendarCheck, Scale, Info, FileText, Copy, Check, Gift, Crown, Camera, Clock } from "lucide-react";
import { Modal } from "./Modal";

export function SignIn({ onDone }: { onDone: () => void }) {
  const [email, setEmail] = useState("ananya.bhat@gmail.com");
  const [pw, setPw] = useState("••••••••");
  return (
    <div className="min-h-screen bg-cream px-5 pt-24 text-cream-ink">
      <div className="mx-auto max-w-md">
        <div className="rounded-3xl bg-cream-ink p-6 pb-16 text-cream">
          <p className="text-[10px] font-bold tracking-[0.25em] text-gold">HOME SERVICE</p>
          <h1 className="mt-2 font-display text-3xl">Welcome back.</h1>
          <p className="mt-1 text-sm opacity-70">Book trusted professionals for your everyday needs.</p>
        </div>
        <form onSubmit={(e) => { e.preventDefault(); onDone(); }} className="-mt-10 mx-3 space-y-3 rounded-3xl bg-cream-card p-5 shadow-xl">
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="w-full rounded-2xl border border-cream-line px-4 py-3 text-sm outline-none focus:border-gold" />
          <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="Password" className="w-full rounded-2xl border border-cream-line px-4 py-3 text-sm outline-none focus:border-gold" />
          <button className="w-full rounded-full bg-cream-ink py-3 text-sm font-bold tracking-wider text-cream">SIGN IN</button>
          <div className="flex items-center gap-3 text-xs text-cream-ink/50"><span className="h-px flex-1 bg-cream-line" />OR<span className="h-px flex-1 bg-cream-line" /></div>
          <button type="button" onClick={onDone} className="w-full rounded-full border border-cream-ink py-3 text-sm font-bold tracking-wider">CREATE NEW ACCOUNT</button>
        </form>
        <p className="mt-6 text-center text-xs text-cream-ink/60">✨ Trusted service at your doorstep ✨</p>
      </div>
    </div>
  );
}

export function TrustRow() {
  return (
    <div>
      <h2 className="mb-3 font-bold">Why choose us?</h2>
      <div className="grid grid-cols-3 gap-2">
        {[[BadgeCheck, "Verified Professionals"], [CalendarCheck, "Easy Booking"], [Scale, "Worker-Governed Equity"]].map(([I, t]) => {
          const Icon = I as typeof BadgeCheck;
          return (
            <div key={t as string} className="rounded-2xl border border-cream-line bg-cream-card p-3 text-center">
              <Icon className="mx-auto h-5 w-5 text-success" />
              <p className="mt-1.5 text-[11px] font-semibold leading-tight">{t as string}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

const items: [string, number][] = [["AC General Service", 600], ["Parts / Materials", 150], ["Service / Travel Charge", 50], ["Platform Fee", 30], ["Loyalty Discount Applied", -50]];

export function BillCard() {
  const [open, setOpen] = useState(false);
  const [tip, setTip] = useState(false);
  const Rows = () => (
    <>
      {items.map(([k, v]) => (
        <div key={k} className="flex justify-between py-1.5 text-sm">
          <span className="flex items-center gap-1">{k}{k === "Platform Fee" && <button type="button" aria-label="About platform fee" onClick={() => setTip(!tip)}><Info className="h-3.5 w-3.5 text-cream-ink/50" /></button>}</span>
          <span className={v < 0 ? "font-semibold text-success" : ""}>{v < 0 ? `-₹${-v}` : `₹${v}`}</span>
        </div>
      ))}
      {tip && <p className="rounded-xl bg-gold-soft p-2 text-xs">₹30 funds the cooperative's app, insurance and the worker welfare pool — no hidden commission on the worker's pay.</p>}
      <div className="mt-2 flex justify-between border-t border-cream-line pt-2 font-bold"><span>Total</span><span>₹780</span></div>
    </>
  );
  return (
    <div className="rounded-3xl border border-cream-line bg-cream-card p-5">
      <p className="mb-2 font-bold">Bill summary</p>
      <Rows />
      <button onClick={() => setOpen(true)} className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-cream-ink py-2.5 text-sm font-bold text-cream"><FileText className="h-4 w-4" /> View / Download Bill</button>
      <div className="mt-4 rounded-2xl bg-cream p-3">
        <p className="mb-2 text-xs font-bold">Evidence chain</p>
        {[[Clock, "4:28 PM — Arrival verified (GPS)"], [FileText, "4:41 PM — Estimate ₹780 approved by you"], [Camera, "5:20 PM — Before/after photos uploaded"], [Check, "5:32 PM — Work completed"]].map(([I, t]) => {
          const Icon = I as typeof Clock;
          return <p key={t as string} className="flex items-center gap-2 py-1 text-xs"><Icon className="h-3.5 w-3.5 text-success" />{t as string}</p>;
        })}
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title="Invoice">
        <div className="mb-3 grid grid-cols-2 gap-2 text-xs">
          <div><p className="text-cream-ink/50">Booking ID</p><p className="font-semibold">CG-BLR-20481</p></div>
          <div><p className="text-cream-ink/50">Provider</p><p className="font-semibold">Arjun Rao</p></div>
          <div><p className="text-cream-ink/50">Date</p><p className="font-semibold">08 Oct 2026</p></div>
          <div><p className="text-cream-ink/50">Warranty</p><p className="font-semibold text-success">Active · 30 days</p></div>
        </div>
        <Rows />
        <button onClick={() => window.print()} className="mt-4 w-full rounded-full bg-gold py-3 text-sm font-bold text-gold-ink">Download PDF</button>
      </Modal>
    </div>
  );
}

export function Rewards() {
  const [copied, setCopied] = useState(false);
  return (
    <div className="space-y-5">
      <h1 className="font-display text-3xl">Rewards</h1>
      <div className="rounded-3xl bg-cream-ink p-5 text-cream">
        <p className="flex items-center gap-2 text-sm font-bold"><Crown className="h-4 w-4 text-gold" /> Silver member</p>
        <p className="mt-2 text-xs opacity-70">7/10 bookings to unlock Gold — 5% discount</p>
        <div className="mt-2 h-2 rounded-full bg-cream/20"><div className="h-2 w-[70%] rounded-full bg-gold" /></div>
      </div>
      <p className="rounded-2xl bg-gold-soft p-3 text-sm">🎉 You're only 3 bookings away from Gold discounts!</p>
      <div className="rounded-3xl border border-cream-line bg-cream-card p-5">
        <p className="flex items-center gap-2 font-bold"><Gift className="h-4 w-4 text-gold" /> Refer & Earn</p>
        <div className="mt-3 flex items-center justify-between rounded-2xl border border-dashed border-gold p-3">
          <span className="font-mono text-lg font-bold tracking-widest">ANANYA50</span>
          <button onClick={() => { navigator.clipboard?.writeText("ANANYA50"); setCopied(true); setTimeout(() => setCopied(false), 1500); }} className="flex items-center gap-1 rounded-full bg-gold px-3 py-1.5 text-xs font-bold text-gold-ink">
            {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}{copied ? "Copied" : "Copy"}
          </button>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-2 text-center">
          {[["125", "Points"], ["4", "Invited"], ["2", "Joined"]].map(([v, k]) => (
            <div key={k} className="rounded-2xl bg-cream p-2"><p className="font-bold">{v}</p><p className="text-[10px] text-cream-ink/60">{k}</p></div>
          ))}
        </div>
      </div>
    </div>
  );
}
