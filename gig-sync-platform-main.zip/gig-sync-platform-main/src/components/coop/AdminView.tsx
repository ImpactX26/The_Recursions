import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { SlidersHorizontal, Play, CheckCircle2, Brain, Network, RotateCcw } from "lucide-react";

const defaults = [
  { k: "Skill Match", v: 30 },
  { k: "Service Quality", v: 20 },
  { k: "Reliability", v: 15 },
  { k: "Distance / ETA", v: 10 },
  { k: "Availability", v: 10 },
  { k: "Workload", v: 5 },
  { k: "Opportunity Equity", v: 10 },
];

function project(w: number[]) {
  const eq = w[6] ?? 10, eta = w[3] ?? 10, q = w[1] ?? 20;
  return [
    { k: "Inequality Impact", v: -(eq * 3), unit: "%", good: true },
    { k: "ETA Projection", v: +(1.4 + (10 - eta) * 0.15 + (eq - 10) * 0.05).toFixed(1), unit: " min", good: false },
    { k: "Worker Utilization", v: Math.round(eq * 0.5), unit: "%", good: true },
    { k: "Customer CSAT", v: +(-0.3 + (q - 20) * 0.05 - (eq - 10) * 0.03).toFixed(1), unit: "%", good: true },
  ];
}

export function AdminView() {
  const [w, setW] = useState(defaults.map((d) => d.v));
  const [sim, setSim] = useState(project(defaults.map((d) => d.v)));
  const [status, setStatus] = useState<string | null>(null);
  const total = useMemo(() => w.reduce((a, b) => a + b, 0), [w]);

  return (
    <div className="min-h-screen bg-charcoal pb-12 pt-24 text-charcoal-ink">
      <div className="mx-auto max-w-6xl px-5">
        <div className="mb-6">
          <p className="text-xs font-bold tracking-[0.25em] text-charcoal-mute">BOARDROOM</p>
          <h1 className="font-display text-3xl">Cooperative Algorithm Governance</h1>
        </div>
        <div className="grid gap-5 lg:grid-cols-5">
          <section className="rounded-2xl border border-charcoal-line bg-charcoal-card p-5 lg:col-span-3">
            <div className="mb-4 flex items-center justify-between">
              <p className="flex items-center gap-2 font-bold"><SlidersHorizontal className="h-4 w-4 text-gold" /> Matching weights</p>
              <span className={`rounded-full px-3 py-1 text-xs font-bold ${total === 100 ? "bg-success/20 text-success" : "bg-danger/20 text-danger"}`}>Total {total}%</span>
            </div>
            <div className="space-y-4">
              {defaults.map((d, i) => (
                <div key={d.k}>
                  <div className="flex justify-between text-sm"><span>{d.k}</span><span className="font-bold text-gold">{w[i]}%</span></div>
                  <input type="range" min={0} max={50} value={w[i]} aria-label={d.k}
                    onChange={(e) => { const n = [...w]; n[i] = +e.target.value; setW(n); setStatus(null); }}
                    className="mt-1 w-full accent-gold" />
                </div>
              ))}
            </div>
            <div className="mt-6 flex flex-wrap gap-3">
              <button onClick={() => { setSim(project(w)); setStatus("Simulation complete — digital twin updated."); }} className="flex items-center gap-2 rounded-xl bg-gold px-4 py-2.5 text-sm font-bold text-gold-ink">
                <Play className="h-4 w-4" /> Simulate Policy (Digital Twin)
              </button>
              <button disabled={total !== 100} onClick={() => setStatus("Policy v2.4 applied and published to all members.")} className="flex items-center gap-2 rounded-xl border border-charcoal-line px-4 py-2.5 text-sm font-bold disabled:opacity-40">
                <CheckCircle2 className="h-4 w-4" /> Apply Policy
              </button>
              <button onClick={() => { setW(defaults.map((d) => d.v)); setStatus(null); }} className="flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm text-charcoal-mute"><RotateCcw className="h-4 w-4" /> Reset</button>
            </div>
            {total !== 100 && <p className="mt-3 text-xs text-danger">Weights must total 100% before applying.</p>}
            {status && <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-3 text-sm text-success">{status}</motion.p>}
          </section>

          <div className="space-y-5 lg:col-span-2">
            <section className="rounded-2xl border border-charcoal-line bg-charcoal-card p-5">
              <p className="mb-4 flex items-center gap-2 font-bold"><Network className="h-4 w-4 text-gold" /> Gig Digital Twin Simulation</p>
              <div className="grid grid-cols-2 gap-3">
                {sim.map((m) => {
                  const positive = m.v > 0;
                  const good = m.k === "ETA Projection" ? !positive : m.k === "Inequality Impact" ? !positive : positive;
                  return (
                    <motion.div key={m.k + m.v} initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="rounded-xl bg-charcoal p-3">
                      <p className="text-[11px] text-charcoal-mute">{m.k}</p>
                      <p className={`text-2xl font-bold ${good ? "text-success" : "text-warn"}`}>{positive ? "+" : ""}{m.v}{m.unit}</p>
                    </motion.div>
                  );
                })}
              </div>
            </section>
            <section className="rounded-2xl border border-charcoal-line bg-charcoal-card p-5">
              <p className="mb-3 flex items-center gap-2 font-bold"><Brain className="h-4 w-4 text-gold" /> Cooperative Brain</p>
              {[
                ["31/37 cooling issues resolved by capacitor inspection", 84],
                ["22/26 low water-pressure calls fixed by aerator cleaning", 79],
                ["14/19 MCB trips traced to geyser earthing faults", 71],
              ].map(([t, c]) => (
                <div key={t as string} className="mb-3 rounded-xl bg-charcoal p-3">
                  <p className="text-sm">{t}</p>
                  <div className="mt-2 flex items-center gap-2">
                    <div className="h-1.5 flex-1 rounded-full bg-charcoal-line"><div className="h-1.5 rounded-full bg-gold" style={{ width: `${c}%` }} /></div>
                    <span className="text-xs text-charcoal-mute">{c}% confidence</span>
                  </div>
                </div>
              ))}
            </section>
          </div>
        </div>
        <FairnessAudit />
      </div>
    </div>
  );
}

function FairnessAudit() {
  const [approved, setApproved] = useState<null | boolean>(null);
  const before = [38, 22, 14, 10, 8, 5, 3];
  const after = [22, 18, 16, 14, 12, 10, 8];
  return (
    <div className="mt-5 grid gap-5 lg:grid-cols-2">
      <section className="rounded-2xl border border-charcoal-line bg-charcoal-card p-5">
        <p className="mb-1 font-bold">Fairness Audit — job share by worker decile</p>
        <p className="mb-4 text-xs text-charcoal-mute">Before vs after FairMatch</p>
        <div className="flex h-36 items-end gap-3">
          {before.map((b, i) => (
            <div key={i} className="flex flex-1 items-end gap-1">
              <div className="flex-1 rounded-t bg-charcoal-line" style={{ height: `${b * 3}%` }} />
              <div className="flex-1 rounded-t bg-gold" style={{ height: `${after[i]! * 3}%` }} />
            </div>
          ))}
        </div>
        <div className="mt-4 space-y-2 text-sm">
          <p className="rounded-lg bg-warn/15 p-2 text-warn">⚠ Opportunity concentration detected in Whitefield cluster</p>
          <p className="rounded-lg bg-success/15 p-2 text-success">✓ Inequality decreased by 18% this quarter</p>
        </div>
      </section>
      <section className="rounded-2xl border border-charcoal-line bg-charcoal-card p-5">
        <p className="mb-1 font-bold">AI Dispute Evidence Summary</p>
        <p className="mb-4 text-xs text-charcoal-mute">Dispute #D-318 • Rahul Kumar vs Arjun Rao • AC repair</p>
        <ul className="space-y-2 text-sm">
          <li>• 4 before/after photos — compressor terminal visibly burnt</li>
          <li>• Arrival 4:28 PM (GPS) — within ETA window</li>
          <li>• Estimate ₹780 approved by customer in-app at 4:41 PM</li>
          <li>• AI view: charge consistent with approved estimate (92% confidence)</li>
        </ul>
        {approved === null ? (
          <div className="mt-5 flex gap-3">
            <button onClick={() => setApproved(true)} className="flex-1 rounded-xl bg-gold py-2.5 text-sm font-bold text-gold-ink">Approve recommendation</button>
            <button onClick={() => setApproved(false)} className="flex-1 rounded-xl border border-charcoal-line py-2.5 text-sm font-bold">Escalate to board</button>
          </div>
        ) : (
          <p className="mt-5 text-sm text-success">{approved ? "Resolved — worker payout released." : "Escalated for human board review."}</p>
        )}
      </section>
    </div>
  );
}
