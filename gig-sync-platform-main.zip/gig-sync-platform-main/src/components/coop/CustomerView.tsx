import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  MapPin, Search, Heart, Home, LayoutGrid, CalendarCheck, User, Sparkles, Wrench, Zap, Refrigerator,
  Hammer, PaintRoller, Bug, ShieldCheck, ChevronRight, Check, BookOpen, Star, Bot,
} from "lucide-react";
import { Modal } from "./Modal";
import { SignIn, TrustRow, BillCard, Rewards } from "./CustomerExtras";
import { DiagnosticQuestionnaire } from "./DiagnosticQuestionnaire";
import { Gift } from "lucide-react";

type Tab = "home" | "catalog" | "bookings" | "rewards" | "profile";

const popular = [
  { name: "Home Cleaning", code: "HC", price: 249, icon: Sparkles },
  { name: "Plumbing", code: "PL", price: 329, icon: Wrench },
  { name: "Electrical", code: "EL", price: 409, icon: Zap },
  { name: "AC Repair", code: "AC", price: 489, icon: Refrigerator },
];
const more = [
  { name: "Appliance Repair", code: "AP", price: 809, icon: Refrigerator },
];
const catalog = [
  ...popular,
  ...more,
  { name: "Carpentry", code: "CA", price: 569, icon: Hammer },
  { name: "Painting", code: "PA", price: 649, icon: PaintRoller },
  { name: "Pest Control", code: "PE", price: 729, icon: Bug },
];


const steps = ["Booked", "Confirmed", "Completed"];

export function CustomerView() {
  const [tab, setTab] = useState<Tab>("home");
  const [diag, setDiag] = useState<string | null>(null);
  const [answers, setAnswers] = useState<string[]>([]);
  const [booked, setBooked] = useState<string | null>(null);
  const [passport, setPassport] = useState(false);
  const [why, setWhy] = useState(false);
  const [step, setStep] = useState(0);
  const [fav, setFav] = useState(false);
  const [query, setQuery] = useState("");
  const [authed, setAuthed] = useState(false);

  const openDiag = (name: string) => { setDiag(name); setAnswers([]); setBooked(null); };

  const nav: { id: Tab; label: string; icon: typeof Home }[] = [
    { id: "home", label: "Home", icon: Home },
    { id: "catalog", label: "Services", icon: LayoutGrid },
    { id: "bookings", label: "Bookings", icon: CalendarCheck },
    { id: "rewards", label: "Rewards", icon: Gift },
    { id: "profile", label: "Profile", icon: User },
  ];

  const filtered = catalog.filter((s) => s.name.toLowerCase().includes(query.toLowerCase()));

  if (!authed) return <SignIn onDone={() => setAuthed(true)} />;

  return (
    <div className="min-h-screen bg-cream pb-28 text-cream-ink">
      <div className="mx-auto max-w-md px-5 pt-24">
        <AnimatePresence mode="wait">
          <motion.div key={tab} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.25 }}>
            {tab === "home" && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[10px] font-bold tracking-[0.2em] text-cream-ink/50">SERVICE LOCATION</p>
                    <p className="flex items-center gap-1 font-semibold"><MapPin className="h-4 w-4 text-gold" /> Bengaluru, Karnataka</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => setFav(!fav)} aria-label="Favourites" className="rounded-full border border-cream-line bg-cream-card p-2.5">
                      <Heart className={`h-4 w-4 ${fav ? "fill-danger text-danger" : ""}`} />
                    </button>
                    <div className="grid h-10 w-10 place-items-center rounded-full bg-gold font-bold text-gold-ink">U</div>
                  </div>
                </div>
                <label className="flex items-center gap-3 rounded-2xl border border-cream-line bg-cream-card px-4 py-3">
                  <Search className="h-4 w-4 text-cream-ink/50" />
                  <input value={query} onChange={(e) => setQuery(e.target.value)} onFocus={() => setTab("catalog")} placeholder="Search for plumbing, cleaning…" className="w-full bg-transparent text-sm outline-none" />
                </label>
                <div className="relative overflow-hidden rounded-3xl bg-cream-ink p-6 text-cream">
                  <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-gold/30 blur-2xl" />
                  <p className="text-[10px] font-bold tracking-[0.25em] text-gold">HOME SERVICES</p>
                  <h1 className="mt-2 font-display text-3xl leading-tight">Your home. Taken care of by worker-owners.</h1>
                  <button onClick={() => setTab("catalog")} className="mt-5 rounded-full bg-gold px-5 py-2.5 text-sm font-bold text-gold-ink transition hover:brightness-105">Book now</button>
                </div>
                <div>
                  <div className="mb-3 flex items-center justify-between">
                    <h2 className="font-bold">Popular Services</h2>
                    <button onClick={() => setTab("catalog")} className="text-xs font-semibold text-gold-ink/70">See all</button>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {popular.map((s) => (
                      <button key={s.code} onClick={() => openDiag(s.name)} className="rounded-3xl border border-cream-line bg-cream-card p-4 text-left transition hover:-translate-y-0.5 hover:shadow-lg">
                        <div className="flex items-center justify-between">
                          <s.icon className="h-6 w-6 text-gold" />
                          <span className="rounded-full bg-gold-soft px-2 py-0.5 text-[10px] font-bold text-gold-ink">{s.code}</span>
                        </div>
                        <p className="mt-4 font-semibold">{s.name}</p>
                        <p className="text-xs text-cream-ink/60">Starting at ₹{s.price}</p>
                      </button>
                    ))}
                  </div>
                </div>
                <TrustRow />
              </div>
            )}

            {tab === "catalog" && (
              <div className="space-y-5">
                <h1 className="font-display text-3xl">Service Catalog</h1>
                <label className="flex items-center gap-3 rounded-2xl border border-cream-line bg-cream-card px-4 py-3">
                  <Search className="h-4 w-4 text-cream-ink/50" />
                  <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search services" className="w-full bg-transparent text-sm outline-none" />
                </label>
                <button onClick={() => setPassport(true)} className="flex w-full items-center gap-4 rounded-3xl bg-gold-soft p-4 text-left">
                  <BookOpen className="h-8 w-8 text-gold-ink" />
                  <div className="flex-1">
                    <p className="font-bold">Appliance Service Passport</p>
                    <p className="text-xs text-cream-ink/60">Daikin 1.5T Split AC • 4 service records</p>
                  </div>
                  <ChevronRight className="h-5 w-5" />
                </button>
                <div className="space-y-3">
                  {filtered.map((s) => (
                    <div key={s.code} className="flex items-center gap-4 rounded-3xl border border-cream-line bg-cream-card p-4">
                      <div className="grid h-12 w-12 place-items-center rounded-2xl bg-cream"><s.icon className="h-5 w-5 text-gold" /></div>
                      <div className="flex-1">
                        <p className="font-semibold">{s.name} <span className="ml-1 rounded-full bg-gold-soft px-2 py-0.5 text-[10px] font-bold text-gold-ink">{s.code}</span></p>
                        <p className="text-xs text-cream-ink/60">Starting at ₹{s.price}</p>
                      </div>
                      <button onClick={() => openDiag(s.name)} className="rounded-full bg-gold px-4 py-2 text-xs font-bold text-gold-ink">Book</button>
                    </div>
                  ))}
                  {filtered.length === 0 && <p className="text-center text-sm text-cream-ink/60">No services match “{query}”.</p>}
                </div>
              </div>
            )}

            {tab === "bookings" && (
              <div className="space-y-5">
                <h1 className="font-display text-3xl">My Bookings</h1>
                <div className="rounded-3xl border border-cream-line bg-cream-card p-5">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-[10px] font-bold tracking-[0.2em] text-gold-ink/70">ACTIVE SERVICE</p>
                      <p className="mt-1 text-lg font-bold">AC Repair & Gas Check</p>
                      <p className="text-xs text-cream-ink/60">Today, 4:30 PM • HSR Layout</p>
                    </div>
                    <p className="text-lg font-bold">₹809</p>
                  </div>
                  <div className="mt-4 flex items-center gap-3 rounded-2xl bg-cream p-3">
                    <div className="grid h-10 w-10 place-items-center rounded-full bg-violet font-bold text-violet-ink">AR</div>
                    <div className="flex-1">
                      <p className="font-semibold">Arjun Rao</p>
                      <p className="flex items-center gap-1 text-xs text-cream-ink/60"><Star className="h-3 w-3 fill-gold text-gold" /> 4.8 • 312 jobs</p>
                    </div>
                    <div className="sr-only" /><button onClick={() => setWhy(true)} className="flex items-center gap-1 rounded-full bg-gold-soft px-3 py-1.5 text-[11px] font-bold text-gold-ink">
                      <ShieldCheck className="h-3.5 w-3.5" /> FairMatch 88.7
                    </button>
                  </div>
                  <div className="mt-5">
                    <div className="relative flex justify-between">
                      <div className="absolute left-4 right-4 top-4 h-1 rounded bg-cream-line" />
                      <motion.div className="absolute left-4 top-4 h-1 rounded bg-gold" animate={{ width: `calc(${(step / 2) * 100}% - ${step === 0 ? 0 : 2}rem)` }} />
                      {steps.map((s, i) => (
                        <div key={s} className="relative z-10 flex flex-col items-center gap-1">
                          <div className={`grid h-9 w-9 place-items-center rounded-full border-2 text-xs font-bold ${i <= step ? "border-gold bg-gold text-gold-ink" : "border-cream-line bg-cream-card text-cream-ink/40"}`}>
                            {i < step ? <Check className="h-4 w-4" /> : i + 1}
                          </div>
                          <span className="text-[11px] font-semibold">{s}</span>
                        </div>
                      ))}
                    </div>
                    <button onClick={() => setStep((step + 1) % 3)} className="mt-4 w-full rounded-full border border-cream-line py-2 text-xs font-semibold hover:bg-cream">
                      {step < 2 ? `Simulate: mark ${steps[step + 1]}` : "Reset tracker"}
                    </button>
                  </div>
                </div>
                <BillCard />
                <button onClick={() => setPassport(true)} className="w-full rounded-full border border-cream-ink py-2.5 text-sm font-bold">View Service Passport</button>
                <h2 className="font-bold">Past bookings</h2>
                {[
                  { s: "Deep Home Cleaning", w: "Priya Sharma", d: "28 Sep 2026", p: 1249 },
                  { s: "Kitchen Tap Replacement", w: "Ananya Bhat", d: "14 Sep 2026", p: 329 },
                  { s: "Fan & Switchboard Fix", w: "Arjun Rao", d: "02 Aug 2026", p: 409 },
                ].map((b) => (
                  <div key={b.s} className="flex items-center justify-between rounded-3xl border border-cream-line bg-cream-card p-4">
                    <div>
                      <p className="font-semibold">{b.s}</p>
                      <p className="text-xs text-cream-ink/60">{b.w} • {b.d}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">₹{b.p}</p>
                      <p className="text-[10px] font-bold text-success">COMPLETED</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {tab === "rewards" && <Rewards />}

            {tab === "profile" && (
              <div className="space-y-5">
                <h1 className="font-display text-3xl">Profile</h1>
                <div className="rounded-3xl border border-cream-line bg-cream-card p-5">
                  <div className="flex items-center gap-4">
                    <div className="grid h-16 w-16 place-items-center rounded-full bg-gold text-2xl font-bold text-gold-ink">U</div>
                    <div>
                      <p className="text-lg font-bold">Ananya Bhat</p>
                      <p className="text-xs text-cream-ink/60">Member since Jan 2025</p>
                    </div>
                  </div>
                  <dl className="mt-5 divide-y divide-cream-line">
                    {[["Name", "Ananya Bhat"], ["Email", "ananya.bhat@gmail.com"], ["Phone", "+91 98450 12345"], ["City", "Bengaluru, Karnataka"]].map(([k, v]) => (
                      <div key={k} className="flex justify-between py-3 text-sm">
                        <dt className="text-cream-ink/60">{k}</dt><dd className="font-semibold">{v}</dd>
                      </div>
                    ))}
                  </dl>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      <nav className="fixed bottom-4 left-1/2 z-40 flex w-[calc(100%-2rem)] max-w-sm -translate-x-1/2 justify-around rounded-full border border-cream-line bg-cream-card p-2 shadow-xl">
        {nav.map((n) => (
          <button key={n.id} onClick={() => setTab(n.id)} className={`flex flex-col items-center rounded-full px-3 py-1.5 text-[10px] font-semibold transition ${tab === n.id ? "bg-gold text-gold-ink" : "text-cream-ink/50"}`}>
            <n.icon className="h-5 w-5" />{n.label}
          </button>
        ))}
      </nav>

      <Modal open={!!diag} onClose={() => setDiag(null)} title={`Don't-Send-A-Worker AI • ${diag ?? ""}`}>
        {booked ? (
          <div className="text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-success/15"><Check className="h-7 w-7 text-success" /></div>
            <p className="mt-3 font-bold">{booked}</p>
            <button onClick={() => { setDiag(null); setTab("bookings"); setStep(0); }} className="mt-5 w-full rounded-full bg-gold py-3 font-bold text-gold-ink">View booking</button>
          </div>
        ) : (
          <DiagnosticQuestionnaire
            service={diag ?? ""}
            answers={answers}
            setAnswers={setAnswers}
            onCancel={() => setBooked(`Great — no visit booked for ${diag}. Saved you ₹249 inspection fee!`)}
            onBook={(priority) => setBooked(`${priority ? "Priority booking" : "Booking"} confirmed for ${diag}. Arjun Rao matched via FairMatch.`)}
          />
        )}
      </Modal>

      <Modal open={passport} onClose={() => setPassport(false)} title="Appliance Service Passport">
        <div className="rounded-2xl bg-cream p-4">
          <p className="font-bold">Daikin 1.5T Inverter Split AC</p>
          <p className="text-xs text-cream-ink/60">Model FTKF50 • Installed Mar 2023 • Bedroom</p>
        </div>
        <ol className="mt-4 space-y-4 border-l-2 border-gold pl-5">
          {[
            ["12 Jun 2026", "Capacitor replaced", "Arjun Rao", "₹1,150"],
            ["04 Mar 2026", "Pre-summer deep service", "Priya Sharma", "₹649"],
            ["19 Oct 2025", "Gas top-up (R32)", "Arjun Rao", "₹2,400"],
            ["08 Apr 2025", "Filter clean & PCB check", "Ananya Bhat", "₹499"],
          ].map(([d, t, w, p]) => (
            <li key={d} className="relative">
              <span className="absolute -left-[27px] top-1 h-3 w-3 rounded-full bg-gold" />
              <p className="text-xs text-cream-ink/60">{d}</p>
              <p className="font-semibold">{t}</p>
              <p className="text-xs">{w} • {p}</p>
            </li>
          ))}
        </ol>
      </Modal>

      <Modal open={why} onClose={() => setWhy(false)} title="Why this worker? — FairMatch">
        <p className="mb-4 text-sm text-cream-ink/70">Arjun scored <b>88.7</b> using the cooperative's published policy.</p>
        {[["Skill Match", 96], ["Service Quality", 92], ["Reliability", 89], ["Distance / ETA", 78], ["Availability", 100], ["Opportunity Equity", 68]].map(([k, v]) => (
          <div key={k as string} className="mb-3">
            <div className="flex justify-between text-xs font-semibold"><span>{k}</span><span>{v}</span></div>
            <div className="mt-1 h-2 rounded-full bg-cream"><div className="h-2 rounded-full bg-gold" style={{ width: `${v}%` }} /></div>
          </div>
        ))}
      </Modal>
    </div>
  );
}
