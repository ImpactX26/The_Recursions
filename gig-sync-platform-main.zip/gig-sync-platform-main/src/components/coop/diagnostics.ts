// Service-specific diagnostic trees. Edit questions here — the UI renders them dynamically.
export type Outcome = "no_visit" | "worker" | "priority";
export type DiagOption = { label: string; next?: string; outcome?: Outcome; advice?: string };
export type DiagNode = { q: string; options: DiagOption[] };
export type DiagTree = { start: string; nodes: Record<string, DiagNode> };

export const outcomeMeta: Record<Outcome, { label: string; tone: string }> = {
  no_visit: { label: "No visit needed", tone: "success" },
  worker: { label: "Worker recommended", tone: "gold" },
  priority: { label: "Priority worker required", tone: "danger" },
};

export const diagnostics: Record<string, DiagTree> = {
  "Home Cleaning": {
    start: "type",
    nodes: {
      type: { q: "What kind of cleaning do you need?", options: [
        { label: "Regular cleaning", next: "size" },
        { label: "Deep cleaning", next: "deep" },
        { label: "Spill / stain", next: "stain" },
      ] },
      size: { q: "How large is the home?", options: [
        { label: "1 BHK", outcome: "worker", advice: "A standard 2-hour clean is ideal." },
        { label: "2–3 BHK", outcome: "worker", advice: "We'll send one worker for a 3–4 hour clean." },
        { label: "Villa / 4+ BHK", outcome: "worker", advice: "A team clean is recommended." },
      ] },
      deep: { q: "Is this for move-in/out or after renovation?", options: [
        { label: "Move-in / move-out", outcome: "worker", advice: "Full deep clean incl. kitchen & bathrooms." },
        { label: "After renovation", next: "debris" },
        { label: "Neither", outcome: "worker", advice: "Standard deep clean recommended." },
      ] },
      debris: { q: "Is there construction dust or debris?", options: [
        { label: "Heavy debris", outcome: "priority", advice: "Specialist team with equipment needed." },
        { label: "Just dust", outcome: "worker", advice: "Post-renovation dust clean." },
      ] },
      stain: { q: "What is the stain on?", options: [
        { label: "Hard floor / tiles", outcome: "no_visit", advice: "Mix warm water with mild detergent and wipe; use baking soda paste for tough spots." },
        { label: "Sofa / carpet", next: "fresh" },
      ] },
      fresh: { q: "Is the stain fresh (under 1 hour)?", options: [
        { label: "Yes", outcome: "no_visit", advice: "Blot (don't rub) with a cold damp cloth, then dab with diluted white vinegar." },
        { label: "No, it's set in", outcome: "worker", advice: "Upholstery shampooing recommended." },
      ] },
    },
  },
  Plumbing: {
    start: "issue",
    nodes: {
      issue: { q: "What's the problem?", options: [
        { label: "Leak", next: "leak" },
        { label: "Blocked drain", next: "drain" },
        { label: "No water", next: "nowater" },
      ] },
      leak: { q: "How bad is the leak?", options: [
        { label: "Slow drip from tap", next: "tap" },
        { label: "Pipe leaking steadily", outcome: "worker", advice: "Place a bucket and turn off the local valve until the plumber arrives." },
        { label: "Burst / flooding", outcome: "priority", advice: "Shut the main water valve immediately and switch off power near the water." },
      ] },
      tap: { q: "Have you tightened the tap handle fully?", options: [
        { label: "Not yet", outcome: "no_visit", advice: "Close the tap firmly; if the drip stops, the washer is fine for now." },
        { label: "Yes, still drips", outcome: "worker", advice: "Likely a worn washer or cartridge — quick fix." },
      ] },
      drain: { q: "Which drain is blocked?", options: [
        { label: "Kitchen / wash basin", next: "plunger" },
        { label: "Toilet", next: "overflow" },
        { label: "Main sewer line", outcome: "priority", advice: "Avoid using any water outlets until inspected." },
      ] },
      plunger: { q: "Have you tried hot water or a plunger?", options: [
        { label: "No", outcome: "no_visit", advice: "Pour hot water with baking soda + vinegar, wait 15 min, then plunge." },
        { label: "Yes, still blocked", outcome: "worker" },
      ] },
      overflow: { q: "Is the toilet overflowing?", options: [
        { label: "Yes", outcome: "priority", advice: "Close the valve behind the toilet now." },
        { label: "No, slow flush", outcome: "worker" },
      ] },
      nowater: { q: "Is water missing in the whole house?", options: [
        { label: "Whole house", next: "tank" },
        { label: "Only one tap", outcome: "worker", advice: "Likely a blocked aerator or valve." },
      ] },
      tank: { q: "Have you checked the overhead tank / BWSSB supply?", options: [
        { label: "Tank is empty", outcome: "no_visit", advice: "Switch on the motor or check with your society for supply timings." },
        { label: "Tank is full", outcome: "worker", advice: "Possible airlock or blocked inlet pipe." },
      ] },
    },
  },
  Electrical: {
    start: "issue",
    nodes: {
      issue: { q: "What electrical issue are you facing?", options: [
        { label: "Power outage", next: "outage" },
        { label: "Sparks / burning smell", next: "spark" },
        { label: "Fan / light not working", next: "fixture" },
      ] },
      outage: { q: "Is the outage in your whole area?", options: [
        { label: "Whole area", outcome: "no_visit", advice: "This is a BESCOM supply issue — call 1912 to report it." },
        { label: "Only my home", next: "mcb" },
      ] },
      mcb: { q: "Has the MCB / main breaker tripped?", options: [
        { label: "Yes", next: "reset" },
        { label: "No", outcome: "worker", advice: "Possible meter or incoming cable fault." },
      ] },
      reset: { q: "Does it trip again after resetting?", options: [
        { label: "No, power is back", outcome: "no_visit", advice: "Avoid running heavy appliances together to prevent overload." },
        { label: "Yes, trips again", outcome: "priority", advice: "Possible short circuit — keep the breaker off." },
      ] },
      spark: { q: "Is it still sparking or smoking?", options: [
        { label: "Yes", outcome: "priority", advice: "Switch off the main supply immediately and stay away from the point." },
        { label: "No, happened once", outcome: "worker", advice: "Don't use that socket until inspected." },
      ] },
      fixture: { q: "Have you tried replacing the bulb or checking the regulator?", options: [
        { label: "No", outcome: "no_visit", advice: "Try a known working bulb, or set the fan regulator to max." },
        { label: "Yes, still not working", next: "switch" },
      ] },
      switch: { q: "Do other points on the same switchboard work?", options: [
        { label: "Yes", outcome: "worker", advice: "Likely a faulty switch, capacitor or fixture." },
        { label: "No, whole board is dead", outcome: "worker", advice: "Loose wiring at the board — needs an electrician." },
      ] },
    },
  },
  "AC Repair": {
    start: "power",
    nodes: {
      power: { q: "Is the AC turning on at all?", options: [
        { label: "Yes", next: "cooling" },
        { label: "No", next: "breaker" },
      ] },
      breaker: { q: "Is the circuit breaker / stabilizer switched on?", options: [
        { label: "No", outcome: "no_visit", advice: "Switch on the breaker/stabilizer and wait 3 minutes. 62% of similar cases resolve without a visit." },
        { label: "Yes", next: "remote" },
        { label: "Not sure", outcome: "no_visit", advice: "Check the MCB labelled 'AC' and the stabilizer light, then retry." },
      ] },
      remote: { q: "Have you replaced the remote batteries?", options: [
        { label: "No", outcome: "no_visit", advice: "Replace the remote batteries and try again." },
        { label: "Yes, still dead", outcome: "worker", advice: "Likely a PCB or capacitor fault." },
      ] },
      cooling: { q: "What's wrong with the cooling?", options: [
        { label: "Air not cold", next: "filter" },
        { label: "Water leaking", outcome: "worker", advice: "Drain pipe is probably blocked." },
        { label: "Burning smell / noise", outcome: "priority", advice: "Switch the AC off now — possible compressor or wiring fault." },
      ] },
      filter: { q: "When were the filters last cleaned?", options: [
        { label: "Over a month ago", outcome: "no_visit", advice: "Remove and wash the filters with water, dry, and refit. Set temp to 24°C." },
        { label: "Recently", next: "outdoor" },
      ] },
      outdoor: { q: "Is the outdoor unit fan running?", options: [
        { label: "Yes", outcome: "worker", advice: "Possibly low gas — gas check recommended." },
        { label: "No", outcome: "priority", advice: "Compressor/capacitor issue — avoid running the AC." },
      ] },
    },
  },
};

// Fallback for services without a dedicated tree.
export const genericTree: DiagTree = {
  start: "urgency",
  nodes: {
    urgency: { q: "How urgent is the issue?", options: [
      { label: "Safety risk / emergency", outcome: "priority" },
      { label: "Needs fixing soon", outcome: "worker" },
      { label: "Just a quick question", outcome: "no_visit", advice: "Our team will call you back with guidance — no visit needed." },
    ] },
  },
};

export const getTree = (service: string) => diagnostics[service] ?? genericTree;
