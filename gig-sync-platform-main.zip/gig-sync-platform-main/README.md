# Coop Connect

Build a comprehensive, modern, production-grade Web Application for a Cooperative Gig Services Platform connecting customers with skilled service workers (Plumbers, Electricians, AC Technicians, Cleaners, Carpenters, Painters, Pest Control).

The design must feature three distinct role interfaces reachable via a persistent top banner demo mode switcher:

1. 👤 Customer View (Soft Cream/Off-White theme #FDFBF7, rounded cards, gold/yellow accents)

2. 👷 Worker View (Vibrant Purple header #7C3AED, clean slate cards, violet badge accents)

3. 📊 Admin & Algorithm Governance View (Dark slate charcoal #1E1E1E dashboard layout)

---

### 🎨 DESIGN SYSTEM & LAYOUT REQUIREMENTS

- Use React, Next.js App Router, Tailwind CSS, Lucide React icons, and Framer Motion for smooth tab transitions.

- Persistent Floating Top Header: "COOP-GIG AI" branding with an interactive pill toggle to seamlessly switch demo roles: [Customer View] | [Worker View] | [Admin / Governance View].

- Mobile-first responsive feel with clean bottom floating navigation bars for Customer and Worker views.

---

### 📱 1. CUSTOMER APPLICATION FLOW

- Home Dashboard:

  - Header showing current location ("SERVICE LOCATION: Bengaluru, Karnataka"), search bar, heart icon, and user avatar ("U").

  - Hero card: "HOME SERVICES - Your home. Taken care of by worker-owners." with a gold "Book now" button.

  - Popular Services Grid (2 Columns with code badges & prices):

    * Home Cleaning [HC] - Starting at ₹249

    * Plumbing [PL] - Starting at ₹329

    * Electrical [EL] - Starting at ₹409

    * Appliance Repair [AP] - Starting at ₹809

- Service Catalog Screen:

  - List of services including Carpentry [CA] (₹569), Painting [PA] (₹649), Pest Control [PE] (₹729) with "Book" action buttons.

  - Interactive "Don't-Send-A-Worker AI Diagnostic" modal: Ask diagnostic questions (e.g., "Is AC turning on?") before confirming booking to avoid unnecessary dispatches.

  - "Appliance Service Passport" card: View persistent repair history for a customer's registered asset (e.g., Daikin 1.5T AC service timeline).

- My Bookings & Tracker:

  - Active Service Card showing service details, assigned worker ("Arjun Rao"), price, and an interactive 3-step progress bar (Matched -> En Route -> Completed).

  - Clear "Why this worker?" FairMatch badge showing transparent score transparency.

  - List of past completed bookings.

- Customer Profile Screen: Personal details card (Name, Email, Phone, City).

---

### 👷 2. SERVICE WORKER APPLICATION FLOW

- Violet Top Banner Header: "Arjun Rao • Service Professional" with an "Equity Debt: 68/100" metric badge.

- Tab Switcher: [Incoming Jobs] | [Opportunity Ledger] | [Skill & Welfare].

- Incoming Jobs & Appeals:

  - Service request cards with customer name, location, price, time, and "Accept Request" button.

  - "Why Was I Not Selected?" audit card for unassigned jobs (e.g., AC Repair 6:30 PM: 82.4 score vs 88.7).

  - Interactive "Challenge Decision (Algorithmic Appeal)" button opening a modal with radio button reasons and a text area to submit appeals for cooperative board review.

- My Opportunity Ledger:

  - Metrics cards: Eligible Jobs (184), Jobs Received (71), Opportunity Capture Rate (38.6%).

  - Opportunity Debt callout box explaining allocation boost mechanisms for workers with lower recent exposure.

- Skill Genome & Welfare Intelligence:

  - Skill progress bars (Residential Cleaning 96%, Deep Sanitization 91%, Appliance Cleaning 84%).

  - Wellbeing notification card monitoring daily travel hours and workload.

---

### 📊 3. COOPERATIVE ADMIN & GOVERNANCE DASHBOARD

- Dark Charcoal Boardroom Theme (#1E1E1E).

- Cooperative Algorithm Governance:

  - Configurable weight sliders for matching parameters:

    * Skill Match (30%)

    * Service Quality (20%)

    * Reliability (15%)

    * Distance / ETA (10%)

    * Availability (10%)

    * Workload (5%)

    * Opportunity Equity (10%)

  - "Simulate Policy (Digital Twin)" and "Apply Policy" action buttons.

- Gig Digital Twin Simulation Card:

  - Projected metrics grid showing Inequality Impact (-30%), ETA Projection (+1.4 min), Worker Utilization (+5%), and Customer CSAT (-0.3%).

- Cooperative Brain (Collective Intelligence):

  - Institutional knowledge card showing diagnostic resolution trends (e.g., "31/37 cooling issues resolved by capacitor inspection, 84% confidence").

---

### 🛠️ DATA & INTERACTION REQUIREMENTS

- Pre-populate all screens with realistic demo data using Indian rupees (₹), Indian names (Arjun Rao, Priya Sharma, Ananya Bhat), and Bengaluru location context.

- All modals (Service Passport, Diagnostic AI, Algorithmic Appeal) must open and close interactively when buttons are clicked.

- Ensure status toggles, sliders, and tab transitions are fully functional in the state.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/7b9989fe-a0be-5965-94ab-c8053029d847).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
